package main

import (
	"fmt"
	"regexp"
	//"strconv"
)
import "C"

func substr(input string, start int, length int) string {
	asRunes := []rune(input)

	if start >= len(asRunes) {
		return ""
	}

	if start+length > len(asRunes) {
		length = len(asRunes) - start
	}

	return string(asRunes[start : start+length])
}

// libre
func isRegex(reg *C.char, val *C.char) bool {

	r, _ := regexp.Compile(C.GoString(reg))

	if r == nil {
		fmt.Printf("isRegex GO >%s< Invalide \r\n", C.GoString(reg))
		return false
	}

	match := r.MatchString(C.GoString(val))

	return match
}


func isTelephone(str *C.char) bool {
	r, _ := regexp.Compile("^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\\s\\./0-9]*$")

	match := r.MatchString(C.GoString(str))
	return match
}

func main() {

	fmt.Println(isRegex(C.CString("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])+[.](?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"), C.CString("coucou@gmail.com")))

	fmt.Println(isTelephone(C.CString("(33) 6 50 00 94 78")))
}
